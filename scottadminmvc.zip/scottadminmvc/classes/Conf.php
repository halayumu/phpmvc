<?php

  namespace LocalHalPH34\ScottAdminMVC\Classes;
  
  class Conf {
    const DB_DNS = "mysql:host=localhost;dbname=ph34scott;charset=utf8";
    const DB_USERNAME = "scott";
    const DB_PASSWORD = "tiger";
  }
