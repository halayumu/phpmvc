<?php

namespace LocalHalPH34\ScottAdminMVC\Classes\dao;

use PDO;
use LocalHalPH34\ScottAdminMVC\Classes\entity\Emp;

class EmpDAO
{

  //PDO DB接続オブジェクト
  private $db;

  //コンストラクタ
  public function __construct(PDO $db)
  {
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $this->db = $db;
  }

  //主キー検索
  public function findByPK(int $id): ?Emp
  {
    $sql = "SELECT * FROM emps WHERE id = :id";
    $stmt = $this->db->prepare($sql);
    $stmt->bindValue(":id", $id, PDO::PARAM_INT);
    $result = $stmt->execute();
    $emp = null;
    if ($result && $row = $stmt->fetch()) {
      $idDb = $row["id"];
      $emNo = $row["em_no"];
      $emName = $row["em_name"];
      $emJob = $row["em_job"];
      $emMgr = $row["em_mgr"];
      $emHiredate = $row["em_hiredate"];
      $emSal = $row["em_sal"];
      $emDpId = $row["dept_id"];

      $emp = new Emp();
      $emp->setId($idDb);
      $emp->setEmNo($emNo);
      $emp->setEmName($emName);
      $emp->setEmJob($emJob);
      $emp->setEmMgr($emMgr);
      $emp->setEmHiredate($emHiredate);
      $emp->setEmSal($emSal);
      $emp->setEmDpId($emDpId);
    }
    return $emp;
  }

  public function findByEmNo(int $emNo): ?Emp
  {
    $sql = "SELECT * FROM emps WHERE em_no = :em_no";
    $stmt = $this->db->prepare($sql);
    $stmt->bindValue(":em_no", $emNo, PDO::PARAM_INT);
    $result = $stmt->execute();
    $emp = null;
    if ($result && $row = $stmt->fetch()) {
      $id = $row["id"];
      $emNo = $row["em_no"];
      $emName = $row["em_name"];
      $emJob = $row["em_job"];
      $emMgr = $row["em_mgr"];
      $emHiredate = $row["em_hiredate"];
      $emSal = $row["em_sal"];
      $emDpId = $row["dept_id"];

      $emp = new Emp();
      $emp->setId($id);
      $emp->setEmNo($emNo);
      $emp->setEmName($emName);
      $emp->setEmJob($emJob);
      $emp->setEmMgr($emMgr);
      $emp->setEmHiredate($emHiredate);
      $emp->setEmSal($emSal);
      $emp->setEmDpId($emDpId);
    }
    return $emp;
  }

  public function findAll(): array
  {
    $sql = "SELECT * FROM emps ORDER BY em_no";
    $stmt = $this->db->prepare($sql);
    $result = $stmt->execute();
    $empList = [];
    while ($row = $stmt->fetch()) {
      $id = $row["id"];
      $emNo = $row["em_no"];
      $emName = $row["em_name"];
      $emJob = $row["em_job"];
      $emMgr = $row["em_mgr"];
      $emHiredate = $row["em_hiredate"];
      $emSal = $row["em_sal"];
      $emDpId = $row["dept_id"];

      $emp = new Emp();
      $emp->setId($id);
      $emp->setEmNo($emNo);
      $emp->setEmName($emName);
      $emp->setEmJob($emJob);
      $emp->setEmMgr($emMgr);
      $emp->setEmHiredate($emHiredate);
      $emp->setEmSal($emSal);
      $emp->setEmDpId($emDpId);
      $empList[$emNo] = $emp;
    }
    return $empList;
  }

  public function insert(Emp $emp): int
  {
    $sqlInsert = "INSERT INTO emps (em_no, em_name, em_job, em_mgr, em_hiredate, em_sal, dept_id) VALUES (:em_no, :em_name, :em_job, :em_mgr, :em_hiredate, :em_sal, :dept_id)";
    $stmt = $this->db->prepare($sqlInsert);
    // echo '<pre>';
    // var_dump($emp);
    // echo '</pre>';
    $stmt->bindValue(":em_no", $emp->getEmNo(), PDO::PARAM_INT);
    $stmt->bindValue(":em_name", $emp->getEmName(), PDO::PARAM_STR);
    $stmt->bindValue(":em_job", $emp->getEmJob(), PDO::PARAM_STR);
    $stmt->bindValue(":em_mgr", $emp->getEmMgr(), PDO::PARAM_INT);
    $stmt->bindValue(":em_hiredate", $emp->getEmHiredate(), PDO::PARAM_STR);
    $stmt->bindValue(":em_sal", $emp->getEmSal(), PDO::PARAM_STR);
    $stmt->bindValue(":dept_id", $emp->getEmDpId(), PDO::PARAM_STR);
    $result = $stmt->execute();
    if ($result) {
      $emId = $this->db->lastInsertId();
    } else {
      $emId = -1;
    }
    return  $emId;
  }

  public function update(Emp $emp): bool
  {
    $sqlUpdate = "UPDATE emps SET em_no = :em_no, em_name = :em_name, em_job = :em_job, em_mgr = :em_mgr, em_hiredate = :em_hiredate, em_sal = :em_sal, dept_id = :dept_id WHERE id = :id";
    $stmt = $this->db->prepare($sqlUpdate);
    // echo '<pre>';
    // var_dump($emp);
    // echo '</pre>';
    $stmt->bindValue(":em_no", $emp->getEmNo(), PDO::PARAM_INT);
    $stmt->bindValue(":em_name", $emp->getEmName(), PDO::PARAM_STR);
    $stmt->bindValue(":em_job", $emp->getEmJob(), PDO::PARAM_STR);
    $stmt->bindValue(":em_mgr", $emp->getEmMgr(), PDO::PARAM_INT);
    $stmt->bindValue(":em_hiredate", $emp->getEmHiredate(), PDO::PARAM_STR);
    $stmt->bindValue(":em_sal", $emp->getEmSal(), PDO::PARAM_STR);
    $stmt->bindValue(":dept_id", $emp->getEmDpId(), PDO::PARAM_STR);
    $stmt->bindValue(":id", $emp->getId(), PDO::PARAM_INT);
    $result = $stmt->execute();
    return $result;
  }

  public function delete(int $id): bool
  {
    $sql = "DELETE FROM emps WHERE id = :id";
    $stmt = $this->db->prepare($sql);
    $stmt->bindValue(":id", $id, PDO::PARAM_INT);
    $result = $stmt->execute();
    return $result;
  }
  //--------------------[上司番号と名前取得処理]--------------------//
  public function NoName() //全件
  {
    $sql = "SELECT em_no,em_name FROM emps";
    $stmt = $this->db->prepare($sql);
    $result = $stmt->execute();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $emName = $row["em_name"];
      $emMgr = $row["em_no"];

      $BossList[] =  $emMgr . ":" . $emName;
    }
    return $BossList;
  }

  public function NoNameOne(string $mgr) //単体
  {
    $sql = "SELECT em_no,em_name FROM emps WHERE em_no =:em_no";
    $stmt = $this->db->prepare($sql);
    $stmt->bindValue(":em_no", $mgr, PDO::PARAM_INT);
    $result = $stmt->execute();

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $emName = $row["em_name"];
      $emMgr = $row["em_no"];

      $BossList =  $emMgr . ":" . $emName;
    }
    return $BossList;
  }
  //--------------------[編集バリデーション]--------------------//
  //----[上司番号(単体)]----//
  public function MgrOne(string $mgr) //単体
  {
    $sql = "SELECT em_no,em_name FROM emps WHERE em_no =:em_no";
    $stmt = $this->db->prepare($sql);
    $stmt->bindValue(":em_no", $mgr, PDO::PARAM_INT);
    $result = $stmt->execute();

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $emName = $row["em_name"];
      $emMgr = $row["em_no"];

      $BossList =  $emMgr . ":" . $emName;
    }
    return $BossList;
  }
}
