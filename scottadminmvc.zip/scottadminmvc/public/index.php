<?php

//TOP画面表示処理

namespace LocalHalPH34\ScottAdminMVC\exec;

require_once($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/vendor/autoload.php");

use Twig\Loader\FilesystemLoader;
use Twig\Environment;

$loader = new
  FilesystemLoader($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/templates"); //このファイル海藻を読み込む
$twig = new Environment($loader);

$html = $twig->render("index.html");
print($html);
