<?php

namespace LocalHalPH34\ScottAdminMVC\exec\emp;

require_once($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/vendor/autoload.php");

use PDO;
use PDOException;
use Twig\Loader\FilesystemLoader;
use Twig\Environment;
use LocalHalPH34\ScottAdminMVC\Classes\Conf;
use LocalHalPH34\ScottAdminMVC\Classes\dao\EmpDAO;
use LocalHalPH34\ScottAdminMVC\Classes\dao\DeptDAO;

$loader = new
  FilesystemLoader($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/templates");
$twig = new Environment($loader);

$templatePath = "emp/empEdit.html";
$assign = [];

$editEmpId = $_POST["editEmpId"]; //ユーザーid

try {
  $db = new PDO(Conf::DB_DNS, Conf::DB_USERNAME, Conf::DB_PASSWORD);
  $empDAO = new EmpDAO($db);
  $deptDAO = new DeptDAO($db);
  $managerList = $empDAO->findAll();

  $emp = $empDAO->findByPK($editEmpId); //全件

  if (empty($emp)) {
    $assign["errorMsg"] = "従業員情報の取得に失敗しました。";
    $templatePath = "error.html";
  } else {
    //--------------------[編集txtドロップダウン加工処理]--------------------//
    //----[雇用日]----//
    $emhiredate = explode("-", $emp->getEmHiredate()); //雇用日分解
    $year = $emhiredate[0]; //年
    $month = $emhiredate[1]; //月
    $day = $emhiredate[2]; //日

    //----[所属部門ID取得]----//
    $DeptIdAll = $deptDAO->DeptIdAll(); //(全件)取得
    $DeptIdOne = $deptDAO->DeptIdOne($emp->getEmDpId()); //(単体)取得

    //--------------------[編集txtデータ処理]--------------------//
    $assign["emid"] = $emp->getId(); //従業員番号//id
    $assign["emNo"] = $emp->getEmNo(); //従業員番号
    $assign["emName"] = $emp->getEmName(); //従業員名
    $assign["emJod"] = $emp->getEmJob(); //役職名
    $assign["emOneMgr"] = $empDAO->NoNameOne($emp->getEmMgr()); //上司番号(単体)
    $assign["emNoName"] = $empDAO->NoName(); //上司番号(全件)
    $assign["emYear"] = $year; //年
    $assign["emMonth"] = $month; //月
    $assign["emDay"] = $day; //日
    $assign["emDeptIdOne"] = $DeptIdOne; //所属部門ID(単体)
    $assign["emDeptIdAll"] = $DeptIdAll; //所属部門ID(全件)
    $assign["emSal"] = $emp->getEmSal(); //給料
  }
} catch (PDOException $ex) {
  var_dump($ex);
  $assign["errorMsg"] = "DB接続に失敗しました。";
  $templatePath = "error.html";
} finally {
  $db = null;
}

$html = $twig->render($templatePath, $assign);
print($html);
