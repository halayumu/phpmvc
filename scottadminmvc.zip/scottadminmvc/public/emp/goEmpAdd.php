<?php

namespace LocalHalPH34\ScottAdminMVC\exec\emp;

require_once($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/vendor/autoload.php");

use PDO;
use PDOException;
use Twig\Loader\FilesystemLoader;
use Twig\Environment;
use LocalHalPH34\ScottAdminMVC\Classes\Conf;
use LocalHalPH34\ScottAdminMVC\Classes\dao\EmpDAO;
use LocalHalPH34\ScottAdminMVC\Classes\dao\DeptDAO;

$loader = new
  FilesystemLoader($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/templates");
$twig = new Environment($loader);

$templatePath = "emp/empAdd.html";
$assign = [];

try {
  //-----------------------[DB接続]----------------------------//
  $db = new PDO(Conf::DB_DNS, Conf::DB_USERNAME, Conf::DB_PASSWORD); //接続

  //----[EmpDAOとDeptDAOインスタンス]----//
  $empDAO = new EmpDAO($db);
  $deptDAO = new DeptDAO($db);

  //--------------------[上司番号処理]--------------------//
  $assign["BossList"] = $empDAO->NoName(); //全件取得

  //--------------------[所属部門ID]---------------------//
  $assign["DeptIdAll"] = $deptDAO->DeptIdAll(); //部門番号と名前全件取得

  if (empty($assign["BossList"])) {
    $assign["errorMsg"] = "従業員情報の取得に失敗しました。";
    $templatePath = "error.html";
  }
} catch (PDOException $ex) {
  var_dump($ex);
  $assign["errorMsg"] = "DB接続に失敗しました。";
  $templatePath = "error.html";
} finally {
  $db = null;
}

$html = $twig->render($templatePath, $assign);
print($html);