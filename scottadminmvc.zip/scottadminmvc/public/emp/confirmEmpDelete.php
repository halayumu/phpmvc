<?php
//従業員情報削除確認画面表示処理

namespace LocalHalPH34\ScottAdminMVC\exec\emp;

require_once($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/vendor/autoload.php");

use PDO;
use PDOException;
use Twig\Loader\FilesystemLoader;
use Twig\Environment;
use LocalHalPH34\ScottAdminMVC\Classes\Conf;
use LocalHalPH34\ScottAdminMVC\Classes\dao\EmpDAO;

$loader = new
  FilesystemLoader($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/templates");
$twig = new Environment($loader);

$templatePath = "emp/empConfirmDelete.html";
$assign = [];

$deleteEmpId = $_POST["deleteEmpId"];

try {
  $db = new PDO(Conf::DB_DNS, Conf::DB_USERNAME, Conf::DB_PASSWORD);
  $empDAO = new EmpDAO($db);
  $emp = $empDAO->findByPK($deleteEmpId);
  if (empty($emp)) {
    $assign["errorMsg"] = "従業員情報の取得に失敗しました。";
    $templatePath = "error.html";
  } else {
    $assign["id"] = $emp->getId();
    $assign["emNo"] = $emp->getEmNo(); //従業員番号
    $assign["emName"] = $emp->getEmName(); //従業員名
    $assign["emJod"] = $emp->getEmJob(); //役職名
    $assign["emMgr"] = $emp->getEmMgr(); //上司番号(全件)
    $assign["emHiredate"] = $emp->getEmHiredate(); //雇用日
    $assign["emDpId"] = $emp->getEmDpId(); //所属部門ID
    $assign["emSal"] = $emp->getEmSal(); //給料
  }
} catch (PDOException $ex) {
  var_dump($ex);
  $assign["errorMsg"] = "DB接続に失敗しました。";
  $templatePath = "error.html";
} finally {
  $db = null;
}

$html = $twig->render($templatePath, $assign);
print($html);
