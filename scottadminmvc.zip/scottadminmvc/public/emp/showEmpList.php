<?php



namespace LocalHalPH34\ScottAdminMVC\exec\emp;

require_once($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/vendor/autoload.php");

use PDO;
use PDOException;
use Twig\Loader\FilesystemLoader;
use Twig\Environment;
use LocalHalPH34\ScottAdminMVC\Classes\Conf;
use LocalHalPH34\ScottAdminMVC\Classes\dao\EmpDAO;

$loader = new
  FilesystemLoader($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/templates");
$twig = new Environment($loader);

$templatePath = "emp/empList.html";
$assign = [];

if (isset($_SESSION["flashMsg"])) {
  $assign["flashMsg"] = $_SESSION["flashMsg"];
  unset($_SESSION["flashMsg"]);
}
try {
  $db = new PDO(Conf::DB_DNS, Conf::DB_USERNAME, Conf::DB_PASSWORD);
  $empDAO = new EmpDAO($db);
  $empList = $empDAO->findAll();
  $assign["empList"] = $empList;

  //----[ホームメッセージ]----//
  session_start();
  if (!empty($_SESSION["flashMsg"])) {
    $flashMsg = $_SESSION["flashMsg"]; //削除メッセージ
    $assign["Msg"] = $flashMsg; //削除メッセージ出力
    unset($_SESSION["flashMsg"]); //配列削除
  }
} catch (PDOException $ex) {
  var_dump($ex);
  $assign["errorMsg"] = "DB接続に失敗しました。";
  $templatePath = "error.html";
} finally {
  $db = null;
}
$html = $twig->render($templatePath, $assign);
print($html);