<?php

namespace LocalHalPH34\ScottAdminMVC\exec\emp;

require_once($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/vendor/autoload.php");

use PDO;
use PDOException;
use Twig\Loader\FilesystemLoader;
use Twig\Environment;
use LocalHalPH34\ScottAdminMVC\Classes\Conf;
use LocalHalPH34\ScottAdminMVC\Classes\entity\Emp;
use LocalHalPH34\ScottAdminMVC\Classes\dao\empDAO;
use LocalHalPH34\ScottAdminMVC\Classes\dao\DeptDAO;


$loader = new
  FilesystemLoader($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/templates");
$twig = new Environment($loader);

$templatePath = "emp/empAdd.html";
$isRedirect = false;
$assign = [];

//--------------------[POSTデータ加工処理]--------------------//
//----[従業員番号]----//
$addNo = intval($_POST["addEmNo"]); //整数変換

//----[上司番号]----//
$addMgr = explode(":", $_POST["addEmMgr"]); //分解
$addMgr = intval($addMgr[0]); //整数変換

//----[雇用日]----//
$year = $_POST['year'];
$month = $_POST['month'];
$day = $_POST['day'];
$array = array($year, $month, $day);
$addHiredate = implode("-", $array);

//----[所属部門ID]----//
$addDpId = explode(":", $_POST["addEmDpId"]); //分解
$addDpId = str_replace('0', '', $addDpId); //０番削除
$addDpId = intval($addDpId[0]); //整数変換

//--------------------[POSTデータ取得処理]--------------------//
$addEmNo = $addNo; //従業員番号
$addEmName = $_POST["addEmName"]; //従業員名
$addEmJob = $_POST["addEmJob"]; //役職名
$addEmMgr = $addMgr; //上司番号
$addEmHiredate = $addHiredate; //雇用日
$addEmDpId = $addDpId; //所属部門ID
$addEmSal = $_POST["addEmSal"]; //給料

//--------------------[空文字判定処理]--------------------//
//----[半角削除]----//
$addEmName = trim($addEmName);
$addEmJob = trim($addEmJob);

//----[全角削除]----//
$addEmName = str_replace("　", " ", $addEmName);
$addEmJob = str_replace("　", " ", $addEmJob);

//----[半角削除]----//
$addEmName = trim($addEmName);
$addEmJob = trim($addEmJob);
//--------------------[各データ保存処理]--------------------//
$emp = new Emp();
$emp->setEmNo($addEmNo);
$emp->setEmName($addEmName);
$emp->setEmJob($addEmJob);
$emp->setEmMgr($addEmMgr);
$emp->setEmHiredate($addEmHiredate);
$emp->setEmDpId($addEmDpId);
$emp->setEmSal($addEmSal);

//--------------------[バリデーションメッセージ処理]--------------------//
$validationMsgs = [];

if (empty($addEmName)) {
  $validationMsgs[] = "従業員名の入力は必須です。";
}
if (empty($addEmJob)) {
  $validationMsgs[] = "役職の入力は必須です。";
}

try {
  $db = new PDO(Conf::DB_DNS, Conf::DB_USERNAME, Conf::DB_PASSWORD);
  $empDAO = new EmpDAO($db);
  $empDB = $empDAO->findByEmNo($emp->getEmNo());
  $deptDAO = new DeptDAO($db);

  if (!empty($empDB)) {
    $validationMsgs[] = "その従業員番号はすでに使われています。別のものを指定してください。";
  }

  if (empty($validationMsgs)) {
    $emId = $empDAO->insert($emp);

    if ($emId === -1) {
      $assign["errorMsg"] = "情報登録に失敗しました。もう一度はじめからやり直してください。";
      $templatePath = "error.html";
    } else {
      $isRedirect = true;
      session_start();
      $_SESSION["flashMsg"] = "従業員ID" . $emId . "で従業員情報を登録しました。";
    }
  } else {
    //--------------------[バリデーション処理]--------------------//
    $assign["validationMsgs"] = $validationMsgs; //エラーメッセージ
    $assign["emNo"] = $emp->getEmNo(); //従業員番号
    $assign["emName"] = $emp->getEmName(); //名前
    $assign["emJob"] = $emp->getEmJob(); //役職名
    $assign["emOneMgr"] = $_POST["addEmMgr"]; //上司番号(単体)
    $assign["BossList"] = $empDAO->NoName(); //上司番号(全件)
    $assign["emyear"] = $year; //年
    $assign["emmonth"] = $month; //月
    $assign["emday"] = $day; //日
    $assign["EmOneDpId"] = $_POST["addEmDpId"]; //所属部門ID(単体)
    $assign["DeptIdAll"] = $deptDAO->DeptIdAll(); //所属部門ID(全件)
    $assign["emSal"] = $emp->getEmSal(); //給料
  }
} catch (PDOException $ex) {
  var_dump($ex);
  $assign["errorMsg"] = "DB接続に失敗しました。";
  $templatePath = "error.html";
} finally {
  $db = null;
}
if ($isRedirect) {
  header("Location: /ph34/scottadminmvc/public/emp/showEmpList.php");
} else {
  $html = $twig->render($templatePath, $assign);
  print($html);
}