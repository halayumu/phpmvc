<?php

namespace LocalHalPH34\ScottAdminMVC\exec\emp;

require_once($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/vendor/autoload.php");

use PDO;
use PDOException;
use Twig\Loader\FilesystemLoader;
use Twig\Environment;
use LocalHalPH34\ScottAdminMVC\Classes\Conf;
use LocalHalPH34\ScottAdminMVC\Classes\entity\Emp;
use LocalHalPH34\ScottAdminMVC\Classes\dao\empDAO;
use LocalHalPH34\ScottAdminMVC\Classes\dao\DeptDAO;

$loader = new
  FilesystemLoader($_SERVER["DOCUMENT_ROOT"] . "/ph34/scottadminmvc/templates");
$twig = new Environment($loader);

$templatePath = "emp/empEdit.html";
$isRedirect = false;
$assign = [];

//--------------------[POSTデータ加工処理]--------------------//
//---[従業員id]---//
$editEmId = intval($_POST["editEmId"]); //整数

//----[従業員番号]----//
$emNo = intval($_POST["editEmNo"]); //整数変換

//----[上司番号]----//
$emMgr = explode(":", $_POST["editEmMgr"]); //分解
$emMgr = intval($emMgr[0]); //整数変換

//----[雇用日]----//
$year = $_POST['year'];
$month = $_POST['month'];
$day = $_POST['day'];
$array = array($year, $month, $day);
$emHiredate = implode("-", $array);

//----[所属部門ID]----//
$emDpId = explode(":", $_POST["editEmDpId"]); //分解
$emDpId = str_replace('0', '', $emDpId); //０番削除
$emDpId = intval($emDpId[0]); //整数変換

//----[給料]----//
$emSal = intval($_POST["editEmSal"]); //整数変換

//--------------------[POSTデータ取得処理]--------------------//
$editEmId = $editEmId; //従業員ID
$editEmNo = $emNo; //従業員番号
$editEmName = $_POST["editEmName"]; //従業員名
$editEmJob = $_POST["editEmJob"]; //役職
$editEmMgr = $emMgr; //上司番号
$editEmHiredate = $emHiredate; //雇用日
$editEmSal = $emSal; //給料
$editEmDpId = $emDpId; //所属部門ID

$editEmName = trim($editEmName);
$editEmJob = trim($editEmJob);

$editEmName = str_replace("　", " ", $editEmName);
$editEmJob = str_replace("　", " ", $editEmJob);

$editEmName = trim($editEmName);
$editEmJob = trim($editEmJob);

$emp = new Emp();
$emp->setId($editEmId);
$emp->setEmNo($editEmNo);
$emp->setEmName($editEmName);
$emp->setEmJob($editEmJob);
$emp->setEmMgr($editEmMgr);
$emp->setEmHiredate($editEmHiredate);
$emp->setEmSal($editEmSal);
$emp->setEmDpId($editEmDpId);

$validationMsgs = [];

if (empty($editEmName)) {
  $validationMsgs[] = "従業員名の入力は必須です。";
}
if (empty($editEmJob)) {
  $validationMsgs[] = "役職の入力は必須です。";
}

try {
  $db = new PDO(Conf::DB_DNS, Conf::DB_USERNAME, Conf::DB_PASSWORD);
  $empDAO = new EmpDAO($db);
  $managerList = $empDAO->findAll();

  $empDB = $empDAO->findByEmNo($emp->getEmNo());

  $deptDAO = new DeptDAO($db);
  $deptList = $deptDAO->findAll();

  if (!empty($empDB  && $empDB->getId() != $editEmId)) {
    $validationMsgs[] = "その従業員番号はすでに使われています。別のものを指定してください。";
  }
  if (empty($validationMsgs)) {
    $result = $empDAO->update($emp);

    if ($result) {
      session_start();
      $isRedirect = true;
      $_SESSION["flashMsg"] = "従業員ID" . $editEmId . "の従業員情報を更新しました。";
    } else {
      $assign["errorMsg"] = "情報登録に失敗しました。もう一度はじめからやり直してください。";
      $templatePath = "error.html";
    }
  } else {
    $assign["validationMsgs"] = $validationMsgs;
    $assign["emid"] = $emp->getId(); //従業員番号//id
    $assign["emNo"] = $emp->getEmNo(); //従業員番号
    $assign["emName"] = $emp->getEmName(); //名前
    $assign["emJod"] = $emp->getEmJob(); //役職名
    //----[上司番号(単体)]----//
    $getEmOnMgr = $empDAO->MgrOne($emp->getEmMgr());
    $assign["emOneMgr"] = $getEmOnMgr; //上司番号(単体)
    $assign["emNoName"] = $empDAO->NoName(); //上司番号(全件)

    $assign["emYear"] = $year; //年
    $assign["emMonth"] = $month; //月
    $assign["emDay"] = $day; //日
    //----[所属部門ID取得]----//
    $DeptIdOne = $deptDAO->DeptIdOne($emp->getEmDpId()); //(単体)取得
    $DeptIdAll = $deptDAO->DeptIdAll(); //(全件)取得
    $assign["emDeptIdOne"] = $DeptIdOne; //所属部門ID(単体)
    $assign["emDeptIdAll"] = $DeptIdAll; //所属部門ID(全件)
    $assign["emSal"] = $emp->getEmSal(); //給料
  }
} catch (PDOException $ex) {
  var_dump($ex);
  $assign["errorMsg"] = "DB接続に失敗しました。";
  $templatePath = "error.html";
} finally {
  $db = null;
}
if ($isRedirect) {
  header("Location: /ph34/scottadminmvc/public/emp/showEmpList.php");
} else {
  $html = $twig->render($templatePath, $assign);
  print($html);
}